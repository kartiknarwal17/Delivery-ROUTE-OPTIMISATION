import express from "express";
import fetch from "node-fetch";
//import Location from "../models/Location.js";
import Location from "./models/Location.js";

import { dijkstra } from "../utils/dijkstra.js";

const router = express.Router();


  //Body options:
  { startCode: "A", endCode: "D" }  -> uses ALL locations in DB
  { startCode, endCode, codes: ["A","B","C","D"] } -> restrict to subset

router.post("/", async (req, res) => {
  try {
    const { startCode, endCode, codes } = req.body;

    if (!startCode || !endCode) {
      return res.status(400).json({ error: "startCode and endCode are required" });
    }

    const filter = codes?.length ? { code: { $in: codes } } : {};
    const locs = await Location.find(filter).sort({ code: 1 });
    if (locs.length < 2) return res.status(400).json({ error: "Need at least 2 locations" });

    const start = locs.find((l) => l.code === startCode);
    const end = locs.find((l) => l.code === endCode);
    if (!start || !end) return res.status(404).json({ error: "Invalid start or end code" });

    // Build Distance Matrix using Google API
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    const coords = (arr) => arr.map((l) => `${l.lat},${l.lng}`).join("|");
    const origins = coords(locs);
    const destinations = origins;

    const url = `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${encodeURIComponent(
      origins
    )}&destinations=${encodeURIComponent(destinations)}&mode=driving&units=metric&key=${apiKey}`;

    const gRes = await fetch(url);
    const gData = await gRes.json();
    if (gData.status !== "OK") {
      return res.status(502).json({ error: "Google API error", details: gData });
    }

    // Build graph (km) keyed by code
    const graph = {};
    locs.forEach((a, i) => {
      graph[a.code] = {};
      gData.rows[i].elements.forEach((el, j) => {
        if (i !== j && el.status === "OK") {
          graph[a.code][locs[j].code] = el.distance.value / 1000; // km
        }
      });
    });

    // Run Dijkstra
    const { distances, prev } = dijkstra(graph, start.code);

    // Reconstruct path start -> end
    const path = [];
    let cur = end.code;
    while (cur !== null) {
      path.unshift(cur);
      cur = prev[cur];
    }
    const totalKm = distances[end.code];

    res.json({
      nodes: locs.map(({ name, code, lat, lng }) => ({ name, code, lat, lng })),
      graph,
      path,
      totalKm
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
