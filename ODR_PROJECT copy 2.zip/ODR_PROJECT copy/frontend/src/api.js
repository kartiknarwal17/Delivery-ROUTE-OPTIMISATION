const BASE = import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";

export async function fetchLocations() {
  const res = await fetch(`${BASE}/api/locations`);
  if (!res.ok) throw new Error("Failed to fetch locations");
  return res.json();
}

export async function seedLocations() {
  const res = await fetch(`${BASE}/api/locations/seed`, { method: "POST" });
  if (!res.ok) throw new Error("Failed to seed");
  return res.json();
}

export async function optimizeRoute(startCode, endCode, codes) {
  const res = await fetch(`${BASE}/api/optimize`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ startCode, endCode, codes })
  });
  if (!res.ok) throw new Error("Optimization failed");
  return res.json();
}
