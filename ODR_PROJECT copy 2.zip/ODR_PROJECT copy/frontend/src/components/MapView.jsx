// import { GoogleMap, Marker, Polyline, useJsApiLoader } from "@react-google-maps/api";

// export default function MapView({ result }) {
//   const { isLoaded } = useJsApiLoader({
//     googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY
//   });

//   if (!isLoaded) return <div className="loader">Loading map…</div>;

//   const defaultCenter = result?.nodes?.[0]
//     ? { lat: result.nodes[0].lat, lng: result.nodes[0].lng }
//     : { lat: 28.6, lng: 77.2 };

//   // Build polyline from path codes
//   const coordsByCode = Object.fromEntries(
//     (result?.nodes || []).map(n => [n.code, { lat: n.lat, lng: n.lng }])
//   );
//   const pathCoords = (result?.path || []).map(code => coordsByCode[code]).filter(Boolean);

//   return (
//     <div className="map-wrap">
//       <div className="map-container">
//         <GoogleMap center={defaultCenter} zoom={9} mapContainerStyle={{ width: "100%", height: "100%" }}>
//           {(result?.nodes || []).map(n => (
//             <Marker key={n.code} position={{ lat: n.lat, lng: n.lng }} label={n.code} />
//           ))}
//           {pathCoords.length > 1 && (
//             <Polyline path={pathCoords} options={{ strokeColor: "#ef4444", strokeWeight: 4 }} />
//           )}
//         </GoogleMap>
//       </div>
//     </div>
//   );
// }

// ///////.    new code above   ///////
// import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
// import L from "leaflet";
// import "leaflet/dist/leaflet.css";

// // Fix Leaflet icons
// delete L.Icon.Default.prototype._getIconUrl;
// L.Icon.Default.mergeOptions({
//   iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
//   iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
//   shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
// });

// export default function MapView({ start, deliveries }) {
//   const center = [30.3165, 78.0322]; // Dehradun

//   return (
//     <MapContainer center={center} zoom={13} style={{ height: "100vh", width: "100%" }}>
//       <TileLayer
//         url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
//         attribution="© OpenStreetMap contributors"
//       />

//       {/* Warehouse marker */}
//       {start && (
//         <Marker position={[30.3165, 78.0322]}>
//           <Popup>{start}</Popup>
//         </Marker>
//       )}

//       {/* Delivery markers */}
//       {deliveries.map(
//         (loc, i) =>
//           loc && (
//             <Marker key={i} position={[30.3165 + 0.01 * i, 78.0322 + 0.01 * i]}>
//               <Popup>{loc}</Popup>
//             </Marker>
//           )
//       )}
//     </MapContainer>
//   );
// }

////////.    new code below   ///////

import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix Leaflet marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

export default function MapView({ start, deliveries }) {
  // Use Dehradun as center
  const center = [30.3165, 78.0322];

  // Dummy coordinates for demo route (in real case, use optimization result from backend)
  const demoRoute = [
    [30.3165, 78.0322], // warehouse (start)
    [30.3265, 78.0322], // stop 1
    [30.3265, 78.0422], // stop 2
    [30.3165, 78.0522], // stop 3
    [30.3165, 78.0322], // return to start
  ];

  return (
    <MapContainer center={center} zoom={13} style={{ height: "100vh", width: "100%" }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution="© OpenStreetMap contributors"
      />

      {/* Warehouse marker */}
      {start && (
        <Marker position={demoRoute[0]}>
          <Popup>{start} (Warehouse)</Popup>
        </Marker>
      )}

      {/* Delivery markers */}
      {deliveries.map((loc, i) =>
        loc ? (
          <Marker key={i} position={demoRoute[i + 1]}>
            <Popup>{loc}</Popup>
          </Marker>
        ) : null
      )}

      {/* Route Polyline */}
      <Polyline positions={demoRoute} color="blue" weight={4} opacity={0.7} />
    </MapContainer>
  );
}
