export default function Sidebar({
  start,
  setStart,
  deliveries,
  setDeliveries,
  onOptimize,
  onSeed,
  result,
  loading,
}) {
  const styles = {
    container: {
      width: "320px",
      background: "#ffffff",
      padding: "25px",
      borderRight: "1px solid #eee",
      boxShadow: "2px 0 8px rgba(0,0,0,0.08)",
      display: "flex",
      flexDirection: "column",
      gap: "20px",
      height: "100vh",
      fontFamily: "Arial, sans-serif",
    },
    heading: {
      fontSize: "22px",
      marginBottom: "10px",
      color: "#2c3e50",
      fontWeight: "bold",
      textAlign: "center",
    },
    label: {
      fontWeight: 600,
      color: "#34495e",
      marginBottom: "6px",
      display: "block",
      fontSize: "14px",
    },
    input: {
      width: "100%",
      padding: "10px 12px",
      border: "1px solid #ccc",
      borderRadius: "10px",
      outline: "none",
      fontSize: "14px",
      transition: "0.2s",
    },
    button: {
      padding: "12px 15px",
      border: "none",
      borderRadius: "10px",
      cursor: "pointer",
      fontSize: "15px",
      fontWeight: 600,
      transition: "0.3s",
    },
    buttonPrimary: {
      background: "#3498db",
      color: "#fff",
    },
    buttonSecondary: {
      background: "#2ecc71",
      color: "#fff",
    },
    resultBox: {
      background: "#f9fcff",
      border: "1px solid #d6eaff",
      borderRadius: "10px",
      padding: "15px",
      marginTop: "10px",
    },
    resultTitle: {
      marginBottom: "10px",
      fontSize: "16px",
      color: "#2c3e50",
      fontWeight: "bold",
    },
    resultText: {
      margin: "6px 0",
      color: "#555",
      fontSize: "14px",
    },
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>🚚 Route Optimizer</h2>

      {/* Warehouse Location */}
      <div>
        <label style={styles.label}>Location 1 (Warehouse):</label>
        <input
          type="text"
          placeholder="Enter warehouse location"
          value={start}
          onChange={(e) => setStart(e.target.value)}
          style={styles.input}
        />
      </div>

      {/* Delivery Locations */}
      {[2, 3, 4, 5].map((num, index) => (
        <div key={num}>
          <label style={styles.label}>Location {num} (Delivery):</label>
          <input
            type="text"
            placeholder={`Enter delivery location ${num}`}
            value={deliveries[index] || ""}
            onChange={(e) => {
              const newDeliveries = [...deliveries];
              newDeliveries[index] = e.target.value;
              setDeliveries(newDeliveries);
            }}
            style={styles.input}
          />
        </div>
      ))}

      {/* Buttons */}
      <button
        style={{ ...styles.button, ...styles.buttonPrimary }}
        onClick={onOptimize}
        disabled={loading}
      >
        {loading ? "Optimizing..." : "Optimize Route"}
      </button>

      <button
        style={{ ...styles.button, ...styles.buttonSecondary }}
        onClick={onSeed}
      >
        Seed Sample Locations
      </button>

      {/* Results */}
      {result && (
        <div style={styles.resultBox}>
          <h3 style={styles.resultTitle}>Optimized Route</h3>
          <p style={styles.resultText}>
            <strong>Distance:</strong> {result.distance} km
          </p>
          <p style={styles.resultText}>
            <strong>Duration:</strong> {result.duration} mins
          </p>
        </div>
      )}
    </div>
  );
}
