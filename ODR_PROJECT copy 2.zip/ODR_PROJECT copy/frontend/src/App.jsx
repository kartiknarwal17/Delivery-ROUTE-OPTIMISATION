// import { useEffect, useState } from "react";
// import { fetchLocations, optimizeRoute, seedLocations } from "./api";
// import Sidebar from "./components/Sidebar";
// import MapView from "./components/MapView";

// export default function App() {
//   const [locations, setLocations] = useState([]);
//   const [start, setStart] = useState("");
//   const [end, setEnd] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [result, setResult] = useState(null);

//   const load = async () => {
//     const data = await fetchLocations();
//     setLocations(data);
//     if (data.length >= 2) {
//       setStart(data[0].code);
//       setEnd(data[data.length - 1].code);
//     }
//   };

//   useEffect(() => { load(); }, []);

//   const onOptimize = async () => {
//     if (!start || !end) return alert("Select start and end");
//     setLoading(true);
//     try {
//       const res = await optimizeRoute(start, end);
//       setResult(res);
//     } catch (e) {
//       alert("Failed to optimize. Check backend and API key.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const onSeed = async () => {
//     await seedLocations();
//     await load();
//     setResult(null);
//   };

//   return (
//     <div className="app">
//       <Sidebar
//         locations={locations}
//         start={start}
//         setStart={setStart}
//         end={end}
//         setEnd={setEnd}
//         onOptimize={onOptimize}
//         onSeed={onSeed}
//         result={result}
//         loading={loading}
//       />
//       <MapView result={result} />
//     </div>
//   );
// }

///////.    new code below   ///////

// import { useState } from "react";
// import { fetchLocations, optimizeRoute, seedLocations } from "./api";
// import Sidebar from "./components/Sidebar";
// import MapView from "./components/MapView";


// export default function App() {
//   const [start, setStart] = useState(""); // warehouse location
//   const [deliveries, setDeliveries] = useState(["", "", "", ""]); // 4 delivery points
//   const [result, setResult] = useState(null);
//   const [loading, setLoading] = useState(false);

//   // Fake optimize function
//   const onOptimize = () => {
//     setLoading(true);
//     setTimeout(() => {
//       setResult({ distance: 42, duration: 90 });
//       setLoading(false);
//     }, 1500);
//   };

//   // Seed demo locations
//   const onSeed = () => {
//     setStart("Warehouse - Dehradun");
//     setDeliveries([
//       "Delivery Point 1 - Rajpur Road",
//       "Delivery Point 2 - Clock Tower",
//       "Delivery Point 3 - Premnagar",
//       "Delivery Point 4 - Clement Town",
//     ]);
//   };

//   return (
//     <div style={{ display: "flex" }}>
//       <Sidebar
//         start={start}
//         setStart={setStart}
//         deliveries={deliveries}
//         setDeliveries={setDeliveries}
//         onOptimize={onOptimize}
//         onSeed={onSeed}
//         result={result}
//         loading={loading}
//       />

//       {/* Right side content (map etc.) */}
//       <div style={{ flex: 1, padding: "20px" }}>
//         <h1>Map will render here 🗺️</h1>
//       </div>
//     </div>
//   );
// }

//////.    new code above   ///////

import { useState } from "react";
import Sidebar from "./components/Sidebar";
import MapView from "./components/MapView"; // ✅ Import your map

export default function App() {
  const [start, setStart] = useState(""); // warehouse location
  const [deliveries, setDeliveries] = useState(["", "", "", ""]); // 4 delivery points
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  // Fake optimize function (replace later with backend API)
  const onOptimize = () => {
    setLoading(true);
    setTimeout(() => {
      setResult({ distance: 42, duration: 90 });
      setLoading(false);
    }, 1500);
  };

  // Seed demo locations
  const onSeed = () => {
    setStart("Warehouse - Dehradun");
    setDeliveries([
      "Delivery Point 1 - Rajpur Road",
      "Delivery Point 2 - Clock Tower",
      "Delivery Point 3 - Premnagar",
      "Delivery Point 4 - Clement Town",
    ]);
  };

  return (
    <div style={{ display: "flex" }}>
      {/* Sidebar on left */}
      <Sidebar
        start={start}
        setStart={setStart}
        deliveries={deliveries}
        setDeliveries={setDeliveries}
        onOptimize={onOptimize}
        onSeed={onSeed}
        result={result}
        loading={loading}
      />

      {/* Map on right */}
      <div style={{ flex: 1 }}>
        <MapView
          start={start}
          deliveries={deliveries}
          result={result}
        />
      </div>
    </div>
  );
}
